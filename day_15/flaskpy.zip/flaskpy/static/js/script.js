console.log("TrackRush JS Loaded");


alert("Welcome to TrackRush Racing!");
